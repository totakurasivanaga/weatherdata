import { Component, OnInit } from '@angular/core';
import { GetWeatherDetailsService } from './services/get-weather-details.service';

@Component({
  selector: 'app-weather-report',
  templateUrl: './weather-report.component.html',
  styleUrls: ['./weather-report.component.css']
})
export class WeatherReportComponent implements OnInit {
  weatherDetails: any;
  viewReport: boolean = false;
  weatherReport: any;

  constructor(private api:GetWeatherDetailsService) { }

  ngOnInit(): void {
    this.api.getWeatherDetails().subscribe(res=> {
      this.weatherDetails = res? (res as any).list : {};
      console.log(this.weatherDetails, "res");
    },
    error=> {
      console.log(error, "error");
    });
  }

  viewWeatherReport(e: any) {
    console.log(e, "event")
    this.viewReport = true;
    this.weatherReport = e;
  }

}
