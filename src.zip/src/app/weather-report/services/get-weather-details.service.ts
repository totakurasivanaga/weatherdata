import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class GetWeatherDetailsService {
  url = 'https://api.openweathermap.org/data/2.5/box/city?bbox=12,32,15,37,10&appid=ac53e6934b4e43070c43f564d7d061ed'
  constructor(private http: HttpClient) { }

  getWeatherDetails () {
    return this.http.get(this.url);
  }
}
